from loguru import logger

from core.video_source import MP4VideoSource
from detectors.yolo_detector import YOLODetector
from events.rule_engine import RuleEngine


class FrameProcessor:

    def __init__(self, video_path):

        self.video_path = video_path

        self.detector = YOLODetector()

        self.rule_engine = RuleEngine()

    def run(self):

        source = MP4VideoSource(self.video_path)

        if not source.open():
            logger.error(f"Não foi possível abrir {self.video_path}")
            return

        frame_count = 0

        while True:

            ret, frame = source.read()

            if not ret:
                break

            frame_count += 1

            results = self.detector.detect(frame)

            result = results[0]

            ids = []

            if result.boxes.id is not None:

                ids = [
                    int(track_id)
                    for track_id in result.boxes.id.cpu().tolist()
                ]

            self.rule_engine.process(ids)

            if frame_count % 30 == 0:

                logger.info(
                    f"Frame {frame_count} | IDs: {ids}"
                )

        source.release()

        logger.success(
            f"Fim do vídeo. Frames: {frame_count}"
        )

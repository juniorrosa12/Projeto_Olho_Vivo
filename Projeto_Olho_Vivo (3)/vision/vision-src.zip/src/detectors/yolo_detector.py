from ultralytics import YOLO
from loguru import logger


class YOLODetector:

    def __init__(self, model_name="yolo11n.pt"):
        logger.info(f"Carregando modelo {model_name}...")
        self.model = YOLO(model_name)
        logger.success("Modelo YOLO carregado.")

    def detect(self, frame):

        results = self.model.track(
            source=frame,
            persist=True,
            tracker="bytetrack.yaml",
            verbose=False
        )

        return results

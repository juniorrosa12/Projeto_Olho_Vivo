from loguru import logger

from api.backend_client import BackendClient


class RuleEngine:

    def __init__(self):

        self.previous_ids = set()

        self.backend = BackendClient()

    def process(self, current_ids):

        current_ids = set(current_ids)

        entered = current_ids - self.previous_ids

        exited = self.previous_ids - current_ids

        for person_id in entered:

            logger.success(
                f"Pessoa entrou | ID={person_id}"
            )

            self.backend.send_event(
                {
                    "type": "person_enter",
                    "id": person_id,
                }
            )

        for person_id in exited:

            logger.warning(
                f"Pessoa saiu | ID={person_id}"
            )

            self.backend.send_event(
                {
                    "type": "person_exit",
                    "id": person_id,
                }
            )

        self.previous_ids = current_ids

from loguru import logger


class BackendClient:

    def send_event(self, event):
        logger.info(f"Backend <- {event}")
